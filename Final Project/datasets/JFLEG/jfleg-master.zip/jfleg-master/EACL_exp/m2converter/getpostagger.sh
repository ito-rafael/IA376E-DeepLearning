wget http://nlp.stanford.edu/software/stanford-postagger-full-2014-08-27.zip
unzip stanford-postagger-full-2014-08-27.zip
rm stanford-postagger-full-2014-08-27.zip
mv stanford-postagger-full-2014-08-27 stanford-postagger

