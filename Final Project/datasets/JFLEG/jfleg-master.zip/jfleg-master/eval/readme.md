## Usage of gleu.py

    python gleu.py -W ignore -r my_reference[0-3].txt -s my_source.txt --hyp my_hypothesis.txt
        
        


